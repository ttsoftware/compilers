Compilers 2013
==============

Toy Compiler for the Compiler Course 2013/2014 at DIKU.

This is the code handed out, which is missing some features, as described in the
DOC folder.

The missing parts should be implemented in groups as a programming project, and
described in a written report which gives details on the design decisions
involved, particularities of the implementation, and how it was systematically
tested.
